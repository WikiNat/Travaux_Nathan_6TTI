﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BiblioVersion1.classes
{
    public class Livre
    {
        private int _id;
        private string _nom;
        private string _prenom;
        private string _titre;
        private int _annee_parution;
        private int _etat;

        public int Id { get { return _id; } }
        public string Nom {  get { return _nom; } }
        public string Prenom { get { return _prenom; } }
        public string Titre { get { return _titre; } }
        public int Annee_Parution { get { return  _annee_parution; } }
        public int Etat { get { return _etat; } set { _etat = value; } }

        public Livre(int id, string nom, string prenom,string titre, int annee_parution ,int etat)
        {
            _id = id;
            _nom = nom;
            _prenom = prenom;
            _titre = titre;
            _annee_parution = annee_parution;
            _etat = etat;
        }

        public bool Degrade()
        {
            _etat--;
            if (_etat <= 0)
            {
                _etat = 0;
                return true;
            }
            return false;
        }
        public string Description()
        {
            return $"Le livre à un id de {_id} créé par {_nom} {_prenom}. Le livre s'appelle {_titre}, il est apparu en {_annee_parution} et il a un état {_etat}";
            ;
        }
    }
}
