﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BiblioVersion1.classes
{
    public class Abonne
    {

		private int _id;

		public int Id
		{
			get { return _id; }
			set { _id = value; }
		}

		private string _nom;

		public string Nom
		{
			get { return _nom; }
			set { _nom = value; }
		}
		private string _prenom;

		public string Prenom
		{
			get { return _prenom; }
			set { _prenom = value; }
		}
		private string _email;

		public string Email
		{
			get { return _email; }
			set { _email = value; }
		}
		private string _login;

		public string Login
		{
			get { return _login; }
			set { _login = value; }
		}

		private string _motDePasse;

		public string MotDePasse
		{
			get { return _motDePasse; }
			set { _motDePasse = value; }
		}


		public Abonne(int id,string nom, string prenom, string email, string login, string motDePasse)
		{
			_id = id;
			_nom = nom;
			_prenom = prenom;
			_email = email;
			_login = login;
			_motDePasse = motDePasse;
		}
		public string Infos()
		{
			return $"Prénom : {_prenom}, Nom : {_nom}, Email : {_email}";	
		}

	}
}
