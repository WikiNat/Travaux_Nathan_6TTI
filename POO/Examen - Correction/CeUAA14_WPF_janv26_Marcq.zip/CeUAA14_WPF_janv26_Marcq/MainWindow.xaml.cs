﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CeUAA14_WPF_janv26_Marcq
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            PrepareJeu();
        }
        public void PrepareJeu()
        {
            ColumnDefinition[] column = new ColumnDefinition[10];
            RowDefinition[] row = new RowDefinition[10];
            Button[,] btn1 = new Button[10, 10];

            int i = 0;
            int j = 0;
            int num = 0;

            //for (i = 0; i < 11; i++)
            //{       
            //    Billy.ColumnDefinitions.Add(column[i]);
            //    Billy.RowDefinitions.Add(row[i]);
            //}
            for (i = 0; i < 10; i++)
            {
                for (j = 0; j < 10; j++)
                {
                    if (i + j % 2 == 0)
                    {
                        btn1[i, j] = new Button();
                        btn1[i, j].Content = num.ToString();
                        btn1[i, j].Foreground = Brushes.Red;
                    }
                    else
                    {

                        btn1[i, j] = new Button();
                        btn1[i, j].Foreground = Brushes.Aqua;
                    }
                }
            }
            //Grid.SetColumn(btn1[i,j], 0);
            //Grid.SetRow(btn1[i, j], 1);
            //GenererplateauNumerique();
        }
        


        static int[,] GenererplateauNumerique(int taille)
        {
            int[,] plateau = new int[taille, taille];
            int valeur = 1;

            // On part de la ligne du bas de la matrice et on remonte vers le haut
            for (int ligne = taille - 1; ligne >= 0; ligne--)
            {
                bool gaucheVersDroite = ((taille - 1 - ligne) % 2 == 0);    // permet de déterminer dans quel sens on compte. On aura une expression vraie quant on compte de gauche à droite

                if (gaucheVersDroite)
                {
                    //On rempli la ligne de gauche à droite en incrémentant le comptage
                    for (int colonne = 0; colonne < taille; colonne++)
                    {
                        plateau[ligne, colonne] = valeur++;
                    }
                }
                else
                {
                    //On rempli la ligne de droite à gauche en incrémentant le comptage
                    for (int colonne = taille - 1; colonne >= 0; colonne--)
                    {
                        plateau[ligne, colonne] = valeur++;
                    }
                }
            }

            return plateau;
        }
        //public void TourJoueur(string symboleJoueur, int numeroJoueur, ref int totalJoueur, ref int[] positionPionJoueur, ref string ancienneValeur)
        //{
        //    Random alea = new Random();         // nombre aléatoire
        //    int taille = btnCases.GetLength(0); // nombre de lignes dans le plateau
        //    int maxCases = taille * taille;     // nombre de cases maximum

        //    // dé sorti
        //    int de = alea.Next(1, 7);

        //    // modification de l'interface pour l'affichage du numéro du joueur et du dé
        //    txtQuiJoue.Text = "Joueur " + numeroJoueur;
        //    txtDe.Text = "Dé : " + de;

        //    // calcul total déjà parcouru par le joueur
        //    totalJoueur += de;

        //    // Si on dépasse le nombre total de cases, on fixe à la dernière possible
        //    if (totalJoueur > maxCases)
        //    {
        //        totalJoueur = maxCases;
        //    }

        //    // Retirer le symbole du joueur à l'ancienne position et faire apparaître le numéro qu'il cachait
        //    btnCases[positionPionJoueur[0], positionPionJoueur[1]].Content = ancienneValeur;
        //    btnCases[positionPionJoueur[0], positionPionJoueur[1]].Foreground = Brushes.Black;

        //    // recherche de la nouvelle position du joueur
        //    int index = totalJoueur - 1;

        //    int ligneDepuisBas = index / taille;
        //    int colonneDansLigne = index % taille;

        //    positionPionJoueur[0] = taille - 1 - ligneDepuisBas;

        //    bool gaucheVersDroite = ligneDepuisBas % 2 == 0;

        //    positionPionJoueur[1] = gaucheVersDroite
        //        ? colonneDansLigne
        //        : taille - 1 - colonneDansLigne;

        //    // Fin de partie
        //    if (totalJoueur == maxCases)
        //    {
        //        txtQuiJoue.Text = "Fin !";
        //        btnAvancer.IsEnabled = false;
        //    }

        //    // mémorisation du numéro de la case sur laquelle on va placer le symbole du joueur
        //    // + affichage de ce symbole
        //    ancienneValeur = btnCases[positionPionJoueur[0], positionPionJoueur[1]].Content.ToString();
        //    btnCases[positionPionJoueur[0], positionPionJoueur[1]].Content = symboleJoueur;
        //    btnCases[positionPionJoueur[0], positionPionJoueur[1]].Foreground = Brushes.Gold;
        //}
    }
}